# Desafío Bíblico — Gracia Camp

Sitio web estático preparado para Vercel.

## Publicación

1. Subir `index.html`, `vercel.json` y `README.md` a la raíz de la rama `main` de `equantum-py/dinamicasj-venes`.
2. En Vercel: Add New > Project > Import Git Repository.
3. Framework Preset: Other; Root Directory: `./`; Build Command: vacío; Output Directory: vacío.
4. Deploy.

## Datos y uso sin conexión

El juego conserva sus recursos embebidos en `index.html` y puede abrirse localmente. Los datos creados en el navegador (preguntas, perfiles, progreso, etc.) se almacenan localmente y no se sincronizan automáticamente entre equipos. Exportar un respaldo JSON desde la aplicación antes de cambiar de computadora, navegador o dominio.

## Juegos

01 Palabras desordenadas · 02 Preguntas bíblicas · 03 Ahorcado bíblico · 04 ¿Quién soy? / ¿Qué lugar es?

Referencia editorial: Reina-Valera 1960.
